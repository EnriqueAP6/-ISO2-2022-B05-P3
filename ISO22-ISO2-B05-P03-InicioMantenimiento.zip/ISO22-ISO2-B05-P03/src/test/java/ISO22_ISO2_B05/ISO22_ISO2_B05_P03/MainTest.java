package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

import static org.junit.Assert.*;

import org.junit.Test;

public class MainTest {

	
	@Test
	public void testConstructor() {

		Main main = new Main();

	}
	
	@Test
	public void testmain() {

		String [] args = null;
		Main.main(args);

	}

}
