package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class CuentaBancaria {

	private static final String TIPO1 = "Cuenta Confort";
	private static final String TIPO2 = "Cuenta Vamos que tú puedes";
	private static final String TIPO3 = "Cuenta Ahorra ahora que puedes";
	private static final String TIPO4 = "Cuenta Saltando del Nido";
	private static final String TIPO5 = "Cuenta Independízate que va siendo hora";
	private static final String TIPO6 = "Cuenta Bienvenido a la Vida Adulta";
	private static final int EDAD18 = 18;
	private static final int EDAD25 = 25;

	public CuentaBancaria() {

	}

	public String devuelveTipoCuenta(final Cliente cliente) {

		String tipo;
		if (cliente.getEdad() < EDAD18 && !cliente.isTrabaja() && !cliente.isIndependizado()) {
			tipo = TIPO1;
		} else if (cliente.getEdad() < EDAD25 && !cliente.isTrabaja() && cliente.isIndependizado()) {
			tipo = TIPO2;
		} else if (EDAD18 <= cliente.getEdad() && cliente.getEdad() <= EDAD25 && cliente.isTrabaja()
				&& !cliente.isIndependizado()) {
			tipo = TIPO3;
		} else if (EDAD18 <= cliente.getEdad() && cliente.getEdad() <= EDAD25 && cliente.isTrabaja()
				&& cliente.isIndependizado()) {
			tipo = TIPO4;
		} else if (cliente.getEdad() > EDAD25 && cliente.isTrabaja() && !cliente.isIndependizado()) {
			tipo = TIPO5;
		} else if (cliente.getEdad() > EDAD25 && cliente.isTrabaja() && cliente.isIndependizado()) {
			tipo = TIPO6;
		} else {
			tipo = "";
		}
		return tipo;

	}
}
