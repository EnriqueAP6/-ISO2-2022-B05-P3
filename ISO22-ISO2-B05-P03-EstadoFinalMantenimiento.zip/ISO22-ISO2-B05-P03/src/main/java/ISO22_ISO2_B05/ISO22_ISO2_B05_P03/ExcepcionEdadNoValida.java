package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class ExcepcionEdadNoValida extends Exception{
	
	public ExcepcionEdadNoValida(final String mensaje) {
		super(mensaje);
	}
}
