package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class Cliente {

	private int edad;
	private boolean trabaja;
	private boolean independizado;

	public Cliente(final int edad,final boolean trabaja,final boolean independizado) throws ExcepcionEdadNoValida {
		setEdad(edad);
		setTrabaja(trabaja);
		setIndependizado(independizado);
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(final int edad) throws ExcepcionEdadNoValida {
		if (edad < 0) {
			throw new ExcepcionEdadNoValida("La edad del cliente debe ser un número entero válido");
		}
		this.edad = edad;
	}

	public boolean isTrabaja() {
		return trabaja;
	}

	public void setTrabaja(final boolean trabaja) {
		this.trabaja = trabaja;
	}

	public boolean isIndependizado() {
		return independizado;
	}

	public void setIndependizado(final boolean independizado) {
		this.independizado = independizado;
	}

}
