package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class Principal {
	
	private final static int EDAD = 15;
	
	public static void main(final String[] args) {
		
		try {
			
			final CuentaBancaria cuentaBancaria = new CuentaBancaria();
			final Cliente cliente = new Cliente(EDAD, false, false);
			System.out.println(cuentaBancaria.devuelveTipoCuenta(cliente));
			
		} catch (ExcepcionEdadNoValida e) {
			System.out.println(e.getMessage());
		}
	} 
}
