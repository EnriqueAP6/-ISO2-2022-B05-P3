package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

import static org.junit.Assert.*;

import org.junit.Test;

public class MainTest {

	
	@Test
	public void testConstructor() {

		Principal main = new Principal();

	}
	
	@Test
	public void testmain() {

		String [] args = null;
		Principal.main(args);

	}

}
