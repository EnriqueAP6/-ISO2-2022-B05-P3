package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class CuentaBancaria {

	public String devuelveTipoCuenta(final Cliente cliente) {
		
		String tipo = "";
		
		if (cliente.get_Edad() < 18 && !cliente.get_Trabaja() && !cliente.get_Independizado())
			tipo = "Cuenta Confort";
		else if (cliente.get_Edad() < 25 && !cliente.get_Trabaja() && cliente.get_Independizado())
			tipo = "Cuenta Vamos que tú puedes";
		else if (18 <= cliente.get_Edad() && cliente.get_Edad() <= 25 && cliente.get_Trabaja() && !cliente.get_Independizado())
			tipo = "Cuenta Ahorra ahora que puedes";
		else if (18 <= cliente.get_Edad() && cliente.get_Edad() <= 25 && cliente.get_Trabaja() && cliente.get_Independizado())
			tipo = "Cuenta Saltando del Nido";
		else if (cliente.get_Edad() >25 && cliente.get_Trabaja() && !cliente.get_Independizado())
			tipo = "Cuenta Independízate que va siendo hora";
		else if (cliente.get_Edad() >25 && cliente.get_Trabaja() && cliente.get_Independizado())
			tipo = "Cuenta Bienvenido a la Vida Adulta";
		
		return tipo;
	}
}
