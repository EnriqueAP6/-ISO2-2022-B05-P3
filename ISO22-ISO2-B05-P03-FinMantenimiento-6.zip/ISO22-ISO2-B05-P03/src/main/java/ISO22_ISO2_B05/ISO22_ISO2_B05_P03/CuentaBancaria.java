package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class CuentaBancaria {

	public String devuelveTipoCuenta(Cliente cliente) {
		
		String tipo = "";
		
		if (cliente.getEdad() < 18 && !cliente.isTrabaja() && !cliente.isIndependizado())
			tipo = "Cuenta Confort";
		else if (cliente.getEdad() < 25 && !cliente.isTrabaja() && cliente.isIndependizado())
			tipo = "Cuenta Vamos que tú puedes";
		else if (18 <= cliente.getEdad() && cliente.getEdad() <= 25 && cliente.isTrabaja() && !cliente.isIndependizado())
			tipo = "Cuenta Ahorra ahora que puedes";
		else if (18 <= cliente.getEdad() && cliente.getEdad() <= 25 && cliente.isTrabaja() && cliente.isIndependizado())
			tipo = "Cuenta Saltando del Nido";
		else if (cliente.getEdad() >25 && cliente.isTrabaja() && !cliente.isIndependizado())
			tipo = "Cuenta Independízate que va siendo hora";
		else if (cliente.getEdad() >25 && cliente.isTrabaja() && cliente.isIndependizado())
			tipo = "Cuenta Bienvenido a la Vida Adulta";
		
		return tipo;
	}
}
