package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

import static org.junit.Assert.*;

import org.junit.Test;

public class CuentaBancariaTest {

	@Test
	public void testCaso1() {
		
		int edad = 15;
		boolean trabaja = false;
		boolean independizado = false;
		
		try {
			CuentaBancaria cuenta = new CuentaBancaria();
			Cliente cliente = new Cliente(edad, trabaja, independizado);
			assertEquals(cuenta.devuelveTipoCuenta(cliente),"Cuenta Confort");
		} catch (ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}

	@Test
	public void testCaso2() {
		
		int edad = 15;
		boolean trabaja = false;
		boolean independizado = true;
		
		try {
			CuentaBancaria cuenta = new CuentaBancaria();
			Cliente cliente = new Cliente(edad, trabaja, independizado);
			assertEquals(cuenta.devuelveTipoCuenta(cliente),"Cuenta Vamos que tú puedes");
		} catch (ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testCaso3() {
		
		int edad = 25;
		boolean trabaja = true;
		boolean independizado = false;
		
		try {
			CuentaBancaria cuenta = new CuentaBancaria();
			Cliente cliente = new Cliente(edad, trabaja, independizado);
			assertEquals(cuenta.devuelveTipoCuenta(cliente),"Cuenta Ahorra ahora que puedes");
		} catch (ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testCaso4() {
		
		int edad = 25;
		boolean trabaja = true;
		boolean independizado = true;
		
		try {
			CuentaBancaria cuenta = new CuentaBancaria();
			Cliente cliente = new Cliente(edad, trabaja, independizado);
			assertEquals(cuenta.devuelveTipoCuenta(cliente),"Cuenta Saltando del Nido");
		} catch (ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testCaso5() {
		
		int edad = 70;
		boolean trabaja = true;
		boolean independizado = false;
		
		try {
			CuentaBancaria cuenta = new CuentaBancaria();
			Cliente cliente = new Cliente(edad, trabaja, independizado);
			assertEquals(cuenta.devuelveTipoCuenta(cliente),"Cuenta Independízate que va siendo hora");
		} catch (ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testCaso6() {
		
		int edad = 70;
		boolean trabaja = true;
		boolean independizado = true;
		
		try {
			CuentaBancaria cuenta = new CuentaBancaria();
			Cliente cliente = new Cliente(edad, trabaja, independizado);
			assertEquals(cuenta.devuelveTipoCuenta(cliente),"Cuenta Bienvenido a la Vida Adulta");
		} catch (ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
}
