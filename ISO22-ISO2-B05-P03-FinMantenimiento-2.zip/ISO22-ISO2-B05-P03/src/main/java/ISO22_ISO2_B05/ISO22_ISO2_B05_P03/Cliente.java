package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class Cliente {

	private int edad;
	private boolean trabaja;
	private boolean independizado;
	
	public Cliente(int edad, boolean trabaja, boolean independizado) throws ExcepcionEdadNoValida {
		set_Edad(edad);
		set_Trabaja(trabaja);
		set_Independizado(independizado);
	}
	
	public int get_Edad() {
		return edad;
	}
	public void set_Edad(int edad) throws ExcepcionEdadNoValida {
		if (edad < 0) {
			throw new ExcepcionEdadNoValida("La edad del cliente debe ser un número entero válido");
		}
		this.edad = edad;
	}
	public boolean get_Trabaja() {
		return trabaja;
	}
	public void set_Trabaja(boolean trabaja) {
		this.trabaja = trabaja;
	}
	public boolean get_Independizado() {
		return independizado;
	}
	public void set_Independizado(boolean independizado) {
		this.independizado = independizado;
	}
	
}
