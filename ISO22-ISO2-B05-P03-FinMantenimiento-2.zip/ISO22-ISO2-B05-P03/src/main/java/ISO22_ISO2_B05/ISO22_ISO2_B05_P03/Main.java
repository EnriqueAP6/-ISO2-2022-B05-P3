package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class Main {

	public static void main(String[] args){

		try {
			
			CuentaBancaria cuentaBancaria = new CuentaBancaria();
			Cliente cliente = new Cliente(15, false, false);
			System.out.println(cuentaBancaria.devuelveTipoCuenta(cliente));
			cliente = new Cliente(-15, true, true);
			
		} catch (ExcepcionEdadNoValida e) {
			System.out.println(e.getMessage());
		}
	}
}
