package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

import static org.junit.Assert.*;

import org.junit.Test;

public class ClienteTest {

	@Test
	public void testSetEdadNoValida() {
		
		int edad = -4;
		
		try {
			Cliente cliente = new Cliente(0,true,false); 
			cliente.set_Edad(edad);
		}catch(ExcepcionEdadNoValida e) {
			assertEquals(e.getMessage(),"La edad del cliente debe ser un número entero válido");
		}
	}

	@Test
	public void testSetEdadValida() {
		
		int edad = 15;
		
		try {
			Cliente cliente = new Cliente(0,true,false); 
			cliente.set_Edad(edad);
		}catch(ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testSetTrabaja() {
		
		boolean trabaja = false;
		
		try {
			Cliente cliente = new Cliente(15,true,false);
			cliente.set_Trabaja(trabaja);
		}catch(ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testSetIndependizado() {
		
		boolean independizado = true;
		
		try {
			Cliente cliente = new Cliente(15,true,false);
			cliente.set_Independizado(independizado);
		}catch(ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testGetEdad() {
		
		int edad = 15;
		
		try {
			Cliente cliente = new Cliente(edad,true,false); 
			assertEquals(cliente.get_Edad(),edad);
		}catch(ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testGetTrabaja() {
		
		boolean trabaja = true;
		
		try {
			Cliente cliente = new Cliente(15,trabaja,false);
			assertEquals(cliente.get_Trabaja(),trabaja);
		}catch(ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	@Test
	public void testGetIndependizado() {
		
		boolean independizado = false;
		
		try {
			Cliente cliente = new Cliente(15,true,independizado);
			assertEquals(cliente.get_Independizado(),independizado);
		}catch(ExcepcionEdadNoValida e) {
			fail("No debería haber saltado la excepción, la edad del cliente es válida");
		}
	}
	
	
}
