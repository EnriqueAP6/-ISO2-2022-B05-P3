package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class Main {

	public static void main(String[] args){

		try {
			final int primeraEdad = 15;
			final int segundaEdad = -15;
			CuentaBancaria cuentaBancaria = new CuentaBancaria();
			Cliente cliente = new Cliente(primeraEdad, false, false);
			System.out.println(cuentaBancaria.devuelveTipoCuenta(cliente));
			cliente = new Cliente(segundaEdad, true, true);
			
		} catch (ExcepcionEdadNoValida e) {
			System.out.println(e.getMessage());
		}
	}
}
