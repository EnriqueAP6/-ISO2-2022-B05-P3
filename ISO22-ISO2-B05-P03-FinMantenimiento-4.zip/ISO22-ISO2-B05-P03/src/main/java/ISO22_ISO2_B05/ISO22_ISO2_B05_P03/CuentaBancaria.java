package ISO22_ISO2_B05.ISO22_ISO2_B05_P03;

public class CuentaBancaria {

	public String devuelveTipoCuenta(Cliente cliente) {
		
		String tipo = "";
		String tipo1 = "Cuenta Confort";
		String tipo2 = "Cuenta Vamos que tú puedes";
		String tipo3 = "Cuenta Ahorra ahora que puedes";
		String tipo4 = "Cuenta Saltando del Nido";
		String tipo5 = "Cuenta Independízate que va siendo hora";
		String tipo6 = "Cuenta Bienvenido a la Vida Adulta";
		final int edad18 = 18;
		final int edad25 = 25;
		
		if (cliente.get_Edad() < edad18 && !cliente.get_Trabaja() && !cliente.get_Independizado())
			tipo = tipo1;
		else if (cliente.get_Edad() < edad25 && !cliente.get_Trabaja() && cliente.get_Independizado())
			tipo = tipo2;
		else if (edad18 <= cliente.get_Edad() && cliente.get_Edad() <= edad25 && cliente.get_Trabaja() && !cliente.get_Independizado())
			tipo = tipo3;
		else if (edad18 <= cliente.get_Edad() && cliente.get_Edad() <= edad25 && cliente.get_Trabaja() && cliente.get_Independizado())
			tipo = tipo4;
		else if (cliente.get_Edad() > edad25 && cliente.get_Trabaja() && !cliente.get_Independizado())
			tipo = tipo5;
		else if (cliente.get_Edad() > edad25 && cliente.get_Trabaja() && cliente.get_Independizado())
			tipo = tipo6;
		
		return tipo;
	}
}
